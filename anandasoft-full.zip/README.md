# ANANDASOFT - Site

Projeto Vite + React + Tailwind com estrutura pronta para deploy.

## Como usar

1. Instale dependências:
   ```
   npm install
   ```

2. Rode em desenvolvimento:
   ```
   npm run dev
   ```

3. Build para produção:
   ```
   npm run build
   ```

4. Deploy:
   - Faça upload deste repositório para o GitHub
   - Conecte o repositório à Vercel (vercel.com) e faça deploy automático
