import React from 'react';
import { Helmet } from 'react-helmet';

function Header() {
  return (
    <header className="bg-white/90 backdrop-blur-sm sticky top-0 z-50 shadow-sm">
      <nav className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-4">
            <a href="#home" className="flex items-center gap-3 no-underline">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" aria-hidden className="rounded-full bg-gradient-to-br from-indigo-600 to-cyan-500 p-1">
                <circle cx="12" cy="12" r="10" fill="white" />
                <path d="M6 12h12" stroke="#6366f1" strokeWidth="1.2" strokeLinecap="round" />
              </svg>
              <span className="font-semibold text-lg text-slate-800">ANANDASOFT</span>
            </a>
          </div>

          <div className="hidden md:flex items-center gap-6">
            <a href="#services" className="text-slate-700 hover:text-slate-900">Serviços</a>
            <a href="#about" className="text-slate-700 hover:text-slate-900">Quem somos</a>
            <a href="#portfolio" className="text-slate-700 hover:text-slate-900">Portfólio</a>
            <a href="#contact" className="text-indigo-600 font-medium border-indigo-600 border px-3 py-1 rounded hover:bg-indigo-50">Contato</a>
          </div>

          <div className="md:hidden">
            <MobileMenu />
          </div>
        </div>
      </nav>
    </header>
  );
}

function MobileMenu() {
  const [open, setOpen] = React.useState(false);
  return (
    <div>
      <button aria-expanded={open} aria-controls="mobile-menu" onClick={() => setOpen(!open)} className="p-2 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-400">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden>
          <path d="M4 6h16M4 12h16M4 18h16" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
      </button>
      {open && (
        <div id="mobile-menu" className="absolute right-4 top-16 bg-white shadow-md rounded-md p-4 w-48">
          <a href="#services" className="block py-2">Serviços</a>
          <a href="#about" className="block py-2">Quem somos</a>
          <a href="#portfolio" className="block py-2">Portfólio</a>
          <a href="#contact" className="block py-2 text-indigo-600 font-medium">Contato</a>
        </div>
      )}
    </div>
  );
}

function Hero() {
  return (
    <section id="home" className="bg-slate-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 leading-tight">Governança, Dados e Sistemas Integrados para organizações que querem crescer com segurança</h1>
            <p className="mt-4 text-slate-600">Implementamos frameworks de governança (COBIT), organização de dados e desenvolvimento seguro de sistemas para melhorar tomada de decisão e reduzir riscos operacionais.</p>

            <div className="mt-6 flex gap-3">
              <a href="#contact" className="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded shadow hover:bg-indigo-700">Solicitar contato</a>
              <a href="#services" className="inline-flex items-center px-4 py-2 border rounded text-slate-700 hover:bg-slate-100">Nossos serviços</a>
            </div>

            <ul className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm text-slate-700">
              <li>• Mapeamento e governança de TI</li>
              <li>• Ontologias e modelagem de processos</li>
              <li>• Desenvolvimento de sistemas integrados</li>
              <li>• Consultoria em proteção de dados</li>
            </ul>
          </div>

          <div className="flex justify-center md:justify-end">
            <div className="w-full max-w-md rounded-lg overflow-hidden shadow-lg bg-white">
              <img src="/images/hero-placeholder.jpg" alt="Equipe de consultoria em reunião" loading="lazy" className="w-full h-64 object-cover" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Services() {
  const items = [
    { title: 'Governança & Compliance (COBIT)', desc: 'Avaliação, implantação e treinamento em governança de TI alinhada ao negócio.' },
    { title: 'Modelagem de Dados e Processos', desc: 'Ontologias, dicionário de dados e integração entre sistemas.' },
    { title: 'Desenvolvimento Seguro', desc: 'Soluções customizadas com foco em arquitetura limpa e boas práticas de segurança.' },
    { title: 'Suporte & Operação', desc: 'Operação assistida, monitoramento e melhoria contínua.' }
  ];

  return (
    <section id="services" className="py-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl font-bold text-slate-900">Serviços</h2>
        <p className="mt-2 text-slate-600 max-w-2xl">Projetos sob medida para empresas que precisam transformar seu ambiente de TI em vantagem estratégica.</p>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {items.map((s) => (
            <article key={s.title} className="bg-white p-5 rounded-lg shadow-sm">
              <h3 className="font-semibold text-slate-800">{s.title}</h3>
              <p className="mt-2 text-slate-600 text-sm">{s.desc}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function Portfolio() {
  const projects = [
    { title: 'Integração Bancária', desc: 'Gateway de cadastros e conciliação com alta segurança.' },
    { title: 'Governança Municipal', desc: 'Modelo de governança para órgãos públicos com foco em compliance.' },
  ];

  return (
    <section id="portfolio" className="bg-slate-50 py-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl font-bold text-slate-900">Portfólio / Cases</h2>
        <p className="mt-2 text-slate-600 max-w-2xl">Alguns projetos selecionados que exemplificam nossa forma de trabalhar.</p>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
          {projects.map((p) => (
            <article key={p.title} className="bg-white p-5 rounded-lg shadow-sm">
              <h3 className="font-semibold text-slate-800">{p.title}</h3>
              <p className="mt-2 text-slate-600 text-sm">{p.desc}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="about" className="py-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl font-bold text-slate-900">Quem somos</h2>
        <p className="mt-2 text-slate-600 max-w-3xl">ANANDASOFT é uma empresa dedicada à governança de TI, modelagem de dados e desenvolvimento seguro. Atuamos com foco em resultados mensuráveis e transferência de conhecimento para as equipes internas dos clientes.</p>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-4 rounded shadow-sm">
            <h4 className="font-semibold">Missão</h4>
            <p className="text-sm text-slate-600 mt-1">Conectar tecnologia e gestão para reduzir riscos e aumentar eficiência.</p>
          </div>
          <div className="bg-white p-4 rounded shadow-sm">
            <h4 className="font-semibold">Visão</h4>
            <p className="text-sm text-slate-600 mt-1">Ser referência regional em governança e integração de dados.</p>
          </div>
          <div className="bg-white p-4 rounded shadow-sm">
            <h4 className="font-semibold">Valores</h4>
            <p className="text-sm text-slate-600 mt-1">Transparência, responsabilidade, e foco em resultados.</p>
          </div>
        </div>
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section id="contact" className="bg-white py-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl font-bold text-slate-900">Contato</h2>
        <p className="mt-2 text-slate-600 max-w-2xl">Entre em contato para uma avaliação gratuita ou para solicitar proposta técnica.</p>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <form className="bg-slate-50 p-6 rounded shadow-sm" onSubmit={(e)=>{e.preventDefault(); alert('Formulário enviado (demo).');}}>
            <label className="block text-sm font-medium text-slate-700">Nome</label>
            <input className="mt-1 block w-full rounded border px-3 py-2" required aria-required="true" />

            <label className="block text-sm font-medium text-slate-700 mt-3">E-mail</label>
            <input type="email" className="mt-1 block w-full rounded border px-3 py-2" required />

            <label className="block text-sm font-medium text-slate-700 mt-3">Mensagem</label>
            <textarea className="mt-1 block w-full rounded border px-3 py-2" rows={4} required />

            <div className="mt-4">
              <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded">Enviar</button>
            </div>
          </form>

          <div className="bg-slate-50 p-6 rounded shadow-sm">
            <h3 className="font-semibold">Informações</h3>
            <p className="mt-2 text-sm text-slate-700">CNPJ: 18.607.149/0001-07 (verificar) · E-mail: contato@anandasoft.com.br</p>
            <address className="not-italic mt-4 text-sm text-slate-700">Endereço: Rua Exemplo 123, Cidade — Estado</address>

            <div className="mt-6 flex gap-3">
              <a href="mailto:contato@anandasoft.com.br" className="text-indigo-600">contato@anandasoft.com.br</a>
              <a href="#" className="text-slate-600">(41) 9xxxx-xxxx</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-300 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between gap-4 items-center">
        <p className="text-sm">© {new Date().getFullYear()} ANANDASOFT — Todos os direitos reservados.</p>
        <nav aria-label="Footer" className="flex gap-4">
          <a href="#privacy" className="text-sm hover:text-white">Privacidade</a>
          <a href="#terms" className="text-sm hover:text-white">Termos</a>
        </nav>
      </div>
    </footer>
  );
}

export default function App(){
  return (
    <div className="font-sans text-slate-700 bg-white">
      <Helmet>
        <title>ANANDASOFT — Governança de TI, Dados e Sistemas Integrados</title>
        <meta name="description" content="ANANDASOFT: Governança de TI (COBIT), modelagem de dados, desenvolvimento seguro e integração de sistemas. Projetos sob medida para resultados mensuráveis." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="canonical" href="https://anandasoft.com.br/" />
        <meta property="og:title" content="ANANDASOFT — Governança de TI, Dados e Sistemas Integrados" />
        <meta property="og:description" content="Consultoria em governança, modelagem de dados e desenvolvimento seguro para empresas." />
        <meta property="og:type" content="website" />
        <script type="application/ld+json">{`{
          "@context": "https://schema.org",
          "@type": "Organization",
          "name": "ANANDASOFT",
          "url": "https://anandasoft.com.br/",
          "logo": "https://anandasoft.com.br/images/logo.png",
          "contactPoint": [{
            "@type": "ContactPoint",
            "email": "contato@anandasoft.com.br",
            "contactType": "sales",
            "areaServed": "BR",
            "availableLanguage": "pt-BR"
          }],
          "sameAs": []
        }`}</script>
      </Helmet>

      <Header />
      <main className="min-h-screen">
        <Hero />
        <Services />
        <Portfolio />
        <About />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
